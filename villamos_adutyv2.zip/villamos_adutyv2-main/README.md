# [ESX] Admin Duty V2 (NEW VERSION) | villamos_adutyv2
Optimized Admin Duty with panel, if you like my work, join our [Discord](https://discord.gg/esnawXn5q5)
# Marvel Studios
[Discord](https://discord.gg/esnawXn5q5) <br/>
[YouTube](https://www.youtube.com/channel/UCEluDSZ6Y4fBB8OkKzcVx8A)
# Preview
[YouTube](https://youtu.be/bfFSfZORnC8)
# Features
-NUI panel <br/>
-Easy permission system <br/>
-Admin tag based on group or on discord roles <br/>
-Discord log <br/>
-Count duty time <br/>
-Server logo over admins head <br/>
-Clothes or ped on duty <br/>
-On/off switchable admin tag, player ids, god mode, speed run, invisibility, anti ragdoll, copy coords, heal, teleport to marker <br/>
# Usage
By default, you can open the panel with O (or /admenu), but it can be binded to any key in settings!
Discord roles
If you want to get the admin tag from discord roles, you need to set Config.DiscordTags to true and create a discord bot and invite it to your server and add the token in Config.BotToken and the guild id in Config.GuildId. The roles can be configured in Config.Admins, you need to add to key the role id instead of the groups!
# Commands
/admenu<br/>
The following commands can be disabled in config:<br/>
/adduty<br/>
/adtag<br/>
/adids<br/>
/adgod<br/>
/adspeed<br/>
/adinvisible<br/>
/adnoragdoll<br/>
/adcoords<br/>
/adheal<br/>
/admarker<br/>
